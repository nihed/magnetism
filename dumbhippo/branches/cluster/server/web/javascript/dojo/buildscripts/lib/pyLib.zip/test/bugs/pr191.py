# PR#191 instances of Java classes missing __class__ attribute

import java.lang.String
s = java.lang.String('s')
s.__class__
