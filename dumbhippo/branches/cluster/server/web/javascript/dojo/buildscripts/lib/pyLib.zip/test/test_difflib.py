import difflib, test_support
test_support.run_doctest(difflib)
