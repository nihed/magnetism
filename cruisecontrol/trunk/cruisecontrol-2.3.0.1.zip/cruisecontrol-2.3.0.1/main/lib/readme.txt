Apache Ant
http://ant.apache.org/

CheckStyle
http://checkstyle.sourceforge.net/

Emma
http://emma.sourceforge.net/

Jakarta Commons
http://jakarta.apache.org/commons/index.html
- Beanutils, CLI, Collections and Logging used by CheckStyle
- Net directly used by CC

Jakarta Regexp
http://jakarta.apache.org/regexp/index.html 

Jakarta ORO
http://jakarta.apache.org/oro/index.html

JavaBeans Activation Framework
http://java.sun.com/products/javabeans/glasgow/jaf.html

Java Communications API
http://java.sun.com/products/javacomm/

JavaMail API
http://java.sun.com/products/javamail/

JDom
http://jdom.org/

JUnit
http://www.junit.org/index.htm

Log4J
http://logging.apache.org/log4j/docs/index.html

MX4J
http://mx4j.sourceforge.net/

Smack
http://www.jivesoftware.com/xmpp/smack/

Xalan-Java
http://xml.apache.org/xalan-j/

Xerces2 Java Parser
http://xml.apache.org/xerces2-j/


jarfile			ver		license		full license (in licenses-dir)
------------------------------------------------------------------------------------------
activation.jar		1.0.2?		Sun BCLA	activation-license.txt (for 1.0.2)
ant.jar			1.6.2		ASL v2.0	apache-license-2.0.txt
ant-launcher.jar	1.6.2		ASL v2.0	apache-license-2.0.txt
ant-junit.jar		1.6.2		ASL v2.0	apache-license-2.0.txt
checkstyle-all-3.1.jar	3.1		LGPL v2.1 & ASL v1.1?
							lgpl-license.txt (from 3.4)
							apache-license-1.1.txt (from 3.4)
comm.jar		2.0win		Sun BCLA	comm-license.txt
emma.jar		2.0.4217	CPL v1.0	cpl-license.txt
emma_ant.jar		2.0.4217	CPL v1.0	cpl-license.txt
win32comm.dll		2.0win		Sun BCLA	comm-license.txt
commons-net-1.1.0.jar	1.1.0		ASL v1.1	apache-license-1.1.txt
jakarta-oro-2.0.3.jar	2.0.3		ASL v1.1	apache-license-1.1.txt
jdom.jar		1.0				jdom-license.txt
junit.jar		3.8.1		CPL v1.0	cpl-license.txt
log4j.jar		1.2.4		ASL v.1.1	apache-license-1.1.txt
mail.jar		1.2		Sun BCLA	mail-license.txt
mx4j.jar		3.0.1		MX4J v1.0	mx4j-license.txt
mx4j-remote.jar		3.0.1		MX4J v1.0	mx4j-license.txt
mx4j-tools.jar		3.0.1		MX4J v1.0	mx4j-license.txt
smack.jar		1.3.0		ASL v1.1	apache-license-1.1.txt
x10.jar			1.0.1		LGPL v2.1	lgpl-license.txt
xalan.jar		2.6.0		ASL v2.0	apache-license-2.0.txt
xerces.jar		2.7.0		ASL v2.0	apache-license-2.0.txt
