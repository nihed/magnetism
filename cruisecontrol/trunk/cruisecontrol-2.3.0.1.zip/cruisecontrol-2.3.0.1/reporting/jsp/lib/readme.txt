Apache Ant
http://ant.apache.org/

Batik SVG Toolkit
http://xml.apache.org/batik/

Cewolf
http://cewolf.sourceforge.net/

CheckStyle
http://checkstyle.sourceforge.net/

Jakarta Commons
http://jakarta.apache.org/commons/index.html
- Beanutils, CLI, Collections and Logging used by CheckStyle
- Net directly used by CC

Jakarta Regexp
http://jakarta.apache.org/regexp/index.html 

Java Servlet Technology
http://java.sun.com/products/servlet/

JCommon Class Library
http://www.jfree.org/jcommon/index.html

JFreeChart
http://www.jfree.org/jfreechart/index.html

JUnit
http://www.junit.org/index.htm

Xalan-Java
http://xml.apache.org/xalan-j/

Xerces2 Java Parser
http://xml.apache.org/xerces2-j/


jarfile			ver	license		full license (in main/lib/licenses)
-----------------------------------------------------------------------------------
ant.jar			same as main/lib
ant-launcher.jar	same as main/lib
ant-junit.jar		same as main/lib
batik-awt-util.jar	1.5.1?	ASL v1.1	apache-license-1.1.txt (from 1.5.1)
batik-svggen.jar	1.5.1?	ASL v1.1	apache-license-1.1.txt (from 1.5.1)
batik-util.jar		1.5.1?	ASL v1.1	apache-license-1.1.txt (from 1.5.1)
cewolf			0.9.8?  LGPL v2.1	lgpl-license.txt
			(Built-By: jfredrick)
checkstyle-all-3.1.jar	same as main/lib
commons-logging.jar 	1.0.3?	ASL v1.1	apache-license-1.1.txt (from 1.0.4)
	(also in checkstyle-all)
jcommon-0.8.0.jar	0.0.8	LGPL v2.1       lgpl-license.txt
jfreechart-0.9.8.jar	0.9.8	LGPL v2.1       lgpl-license.txt
junit.jar		same as main/lib
servlet.jar		???
xalan.jar		same as main/lib
xerces.jar		same as main/lib
