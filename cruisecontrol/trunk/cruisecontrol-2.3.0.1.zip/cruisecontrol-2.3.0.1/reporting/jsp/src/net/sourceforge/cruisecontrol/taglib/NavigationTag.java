/********************************************************************************
 * CruiseControl, a Continuous Integration Toolkit
 * Copyright (c) 2001, ThoughtWorks, Inc.
 * 651 W Washington Ave. Suite 600
 * Chicago, IL 60661 USA
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 *     + Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *
 *     + Redistributions in binary form must reproduce the above
 *       copyright notice, this list of conditions and the following
 *       disclaimer in the documentation and/or other materials provided
 *       with the distribution.
 *
 *     + Neither the name of ThoughtWorks, Inc., CruiseControl, nor the
 *       names of its contributors may be used to endorse or promote
 *       products derived from this software without specific prior
 *       written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 * "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 * LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 * A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE REGENTS OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR
 * PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
 * NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 ********************************************************************************/
package net.sourceforge.cruisecontrol.taglib;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspTagException;
import javax.servlet.jsp.tagext.BodyContent;

import net.sourceforge.cruisecontrol.BuildInfo;
import net.sourceforge.cruisecontrol.util.DateHelper;
import net.sourceforge.cruisecontrol.util.CCTagException;

/**
 *
 */
public class NavigationTag extends CruiseControlBodyTagSupport {
    public static final String LABEL_SEPARATOR = "L";
    public static final String LINK_TEXT_ATTR = "linktext";
    public static final String URL_ATTR = "url";
    public static final String LOG_FILE_ATTR = "logfile";

    private static final SimpleDateFormat LOG_TIME_FORMAT_SECONDS = new SimpleDateFormat("yyyyMMddHHmmss");
    private static final SimpleDateFormat LOG_TIME_FORMAT = new SimpleDateFormat("yyyyMMddHHmm");

    private BuildInfo[] buildInfo; // the log files in the log directory.
    private int count;  // How many times around the loop have we gone.

    private int startingBuildNumber = 0;
    private int finalBuildNumber = Integer.MAX_VALUE;
    private int endPoint;
    private DateFormat dateFormat = null;

    private String extractLogNameFromFileName(String fileName) {
        return fileName.substring(0, fileName.lastIndexOf(".xml"));
    }

    protected String getLinkText(String fileName) throws JspTagException {
        String dateString = "";
        String label = "";
        if (fileName.lastIndexOf(LABEL_SEPARATOR) > -1) {
            dateString = fileName.substring(3, fileName.indexOf(LABEL_SEPARATOR));
            label = " (" + fileName.substring(fileName.indexOf(LABEL_SEPARATOR) + 1, fileName.length())
                    + ")";
        } else {
            dateString = fileName.substring(3, fileName.length());
        }
        DateFormat inputDate = null;
        if (dateString.length() == 14) {
            inputDate = LOG_TIME_FORMAT_SECONDS;
        } else {
            inputDate = LOG_TIME_FORMAT;
        }

        Date date = null;
        try {
            date = inputDate.parse(dateString);
        } catch (ParseException e) {
            err(e);
            throw new CCTagException("Error parsing '" + dateString + "': " + e.getMessage(), e);

        }

        return getDateFormat().format(date) + label;
    }

    public int doStartTag() throws JspException {
        BuildInfo [] logFileNames = findLogFiles();
        //sort links...
        Arrays.sort(logFileNames, new ReversedComparator());
        buildInfo = logFileNames;
        count = Math.max(0, startingBuildNumber);
        endPoint = Math.min(finalBuildNumber, buildInfo.length - 1) + 1;
        if (count < endPoint) {
            return EVAL_BODY_TAG;
        } else {
            return SKIP_BODY;
        }
    }

    private BuildInfo[] findLogFiles() throws JspException {
        File logDir = findLogDir();
        return BuildInfo.loadFromDir(logDir).asArray();
    }

    public void doInitBody() throws JspException {
       setupLinkVariables();
    }

    void setupLinkVariables() throws JspTagException {
        final String fileName = buildInfo[count].getFileName();
        String logName = extractLogNameFromFileName(fileName);
        getPageContext().setAttribute(URL_ATTR, createUrl("log", logName));
        getPageContext().setAttribute(LINK_TEXT_ATTR, getLinkText(logName));
        getPageContext().setAttribute(LOG_FILE_ATTR, logName);
        count++;
    }

    public int doAfterBody() throws JspException {
        if (count < endPoint) {
            setupLinkVariables();
            return EVAL_BODY_TAG;
        } else {
            try {
                BodyContent out = getBodyContent();
                out.writeOut(out.getEnclosingWriter());
            } catch (IOException e) {
                err(e);
                throw new CCTagException("IO Error: " + e.getMessage(), e);
            }
            return SKIP_BODY;
        }
    }

    public int getStartingBuildNumber() {
        return startingBuildNumber;
    }

    public void setStartingBuildNumber(int startingBuildNumber) {
        this.startingBuildNumber = startingBuildNumber;
    }

    public int getFinalBuildNumber() {
        return finalBuildNumber;
    }

    public void setFinalBuildNumber(int finalBuildNumber) {
        this.finalBuildNumber = finalBuildNumber;
    }

    /**
     * Set the DateFormat to use. The default is for US-Style (MM/dd/yyyy HH:mm:ss).
     * @param dateFormatString  the date format to use. Any format appropriate for the java.text.SimpleDataFormat is
     *                          okay to use.
     */
    public void setDateFormat(String dateFormatString) {
        dateFormat = new SimpleDateFormat(dateFormatString);
    }
    
    private DateFormat getDateFormat() {
        if (dateFormat == null) {
            dateFormat = DateHelper.createDateFormat(getLocale());
        }
        return dateFormat;
    }

}
